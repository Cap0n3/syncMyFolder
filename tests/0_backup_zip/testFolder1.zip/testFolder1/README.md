# Test 1

A `target folder` with different files and folders in it.

Everything should be erased from `target folder` (Folder2) and replaced with `source folder` (Folder1) content.

## Structure

Folder1/
├─ SubFolder1/
│  ├─ mySubText1.txt
├─ myImg1.jpg
├─ myText1.txt
Folder2/
├─ SubFolder2/
│  ├─ ToRemoveSub2.txt
├─ ToRemove2.jpg
